import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AIChat from '../../components/ui/AIChat';
import { useAuth } from '../../hooks/useAuth';

export default function AIChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const navigateToExperts = () => {
    router.push('/(tabs)');
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <AIChat userId={user?.id || 'guest'} onNavigateToExperts={navigateToExperts} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});